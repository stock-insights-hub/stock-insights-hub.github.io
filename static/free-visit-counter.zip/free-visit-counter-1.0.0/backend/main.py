from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
import os

app = FastAPI()
templates = Jinja2Templates(directory="backend/templates")

@app.get("/install-guide", response_class=HTMLResponse)
async def install_guide(request: Request):
    return templates.TemplateResponse("install_guide.html", {"request": request})

@app.get("/api-docs", response_class=HTMLResponse)
async def api_docs(request: Request):
    return templates.TemplateResponse("api_docs.html", {"request": request})

@app.get("/stats/login", response_class=HTMLResponse)
async def login(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.get("/stats/sample-dashboard", response_class=HTMLResponse)
async def sample_dashboard(request: Request):
    return templates.TemplateResponse("sample_dashboard.html", {"request": request})
