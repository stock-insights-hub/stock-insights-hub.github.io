## v1.0.0
- 통계 페이지 FastAPI 통합