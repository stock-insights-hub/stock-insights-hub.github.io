# 방문자 카운터

웹사이트를 위한 가볍고 사용하기 쉬운 방문자 카운터로, 아름다운 대시보드와 API를 제공합니다.

![방문자 카운터 대시보드](https://via.placeholder.com/800x400?text=방문자+카운터+대시보드)

## 📋 목차

- [기능](#기능)
- [빠른 시작](#빠른-시작)
- [API 문서](#api-문서)
- [설치](#설치)
- [배포](#배포)
- [구성](#구성)
- [다국어 지원](#다국어-지원)
- [기여하기](#기여하기)
- [라이선스](#라이선스)

## ✨ 기능

- **실시간 추적**: 정확한 카운팅과 중복 방지 기능으로 실시간으로 방문자를 추적하세요
- **반응형 대시보드**: 반응형 대시보드로 어떤 기기에서든 방문자 통계를 확인하세요
- **쉬운 통합**: 간단한 API로 어떤 웹사이트나 애플리케이션에도 쉽게 통합할 수 있습니다
- **다중 웹사이트**: 하나의 계정으로 여러 도메인의 방문자를 추적하세요
- **다국어 지원**: 영어, 한국어, 일본어로 제공됩니다
- **다크/라이트 테마**: 편안한 보기를 위해 다크 테마와 라이트 테마 간 전환 가능
- **중복 방지**: Redis를 사용하여 20분 TTL로 동일한 방문자를 여러 번 카운트하지 않도록 방지
- **시간대 지원**: 방문자의 시간대를 기준으로 "오늘"을 계산합니다

## 🚀 빠른 시작

### 1. 이 스크립트를 웹사이트에 추가하세요

```html
<script>
  (function() {
    const domain = encodeURIComponent(window.location.hostname);
    const timezone = encodeURIComponent(Intl.DateTimeFormat().resolvedOptions().timeZone);
    
    fetch('https://visitor.6developer.com/visit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain, timezone })
    })
    .then(response => response.json())
    .then(data => {
      console.log('방문자 수:', data);
      // 페이지에 카운트를 표시할 수 있습니다
      if (document.getElementById('visitor-count')) {
        document.getElementById('visitor-count').textContent = data.totalCount;
      }
    })
    .catch(error => console.error('오류:', error));
  })();
</script>
```

### 2. 페이지에 카운터 표시하기 (선택사항)

```html
<div>
  방문자: <span id="visitor-count">0</span>
</div>
```

### 3. 통계 확인하기

[https://visitor.6developer.com/login](https://visitor.6developer.com/login)에서 도메인을 입력하여 방문자 통계 대시보드에 접속하세요

## 📊 API 문서

### POST /visit

도메인의 방문자 수를 증가시킵니다.

#### 요청

```
POST https://visitor.6developer.com/visit
Content-Type: application/json

{
  "domain": "example.com",
  "timezone": "Asia/Seoul"
}
```

#### 매개변수

| 이름 | 타입 | 필수 | 설명 |
|------|------|------|------|
| domain | string | 예 | 도메인 이름 (URL 인코딩, http:// 또는 https:// 제외) |
| timezone | string | 아니오 | "오늘"을 계산하기 위한 시간대 (URL 인코딩, 기본값은 UTC) |

#### 응답

```json
{
  "todayCount": 42,
  "totalCount": 1337,
  "dashboardLink": "https://visitor.6developer.com/dashboard?domain=example.com"
}
```

#### 참고사항

- 20분 이내에 동일한 IP와 사용자 에이전트의 중복 방문은 카운트되지 않습니다
- "todayCount"는 제공된 시간대를 기준으로 계산됩니다

### GET /visit

도메인의 현재 방문자 수를 증가시키지 않고 가져옵니다.

#### 요청

```
GET https://visitor.6developer.com/visit?domain=example.com
```

#### 매개변수

| 이름 | 타입 | 필수 | 설명 |
|------|------|------|------|
| domain | string | 예 | 도메인 이름 (URL 인코딩, http:// 또는 https:// 제외) |

#### 응답

```json
{
  "todayCount": 42,
  "totalCount": 1337,
  "dashboardLink": "https://visitor.6developer.com/dashboard?domain=example.com"
}
```

## 💻 설치

### 요구사항

- Python 3.9+
- PostgreSQL
- Redis

### 설정

1. 저장소 복제:

```bash
git clone https://github.com/yourusername/visitor-counter.git
cd visitor-counter
```

2. 가상 환경 생성 및 의존성 설치:

```bash
python -m venv venv
source venv/bin/activate  # Windows의 경우: venv\Scripts\activate
pip install -r requirements.txt
```

3. 데이터베이스 설정:

```bash
flask db init
flask db migrate
flask db upgrade
```

4. `.env` 파일에 환경 변수 구성:

```
DB_USER=niphyang_dev
DB_PASSWORD=5Bh3G%[Ji*$9
DB_HOST=localhost
DB_NAME=niphyang_visitcounter
REDIS_HOST=localhost
REDIS_PORT=59971
REDIS_PASSWORD=
SECRET_KEY=your_secure_secret_key_here
FLASK_ENV=production
```

5. 애플리케이션 실행:

```bash
flask run
```

## 🌐 배포

### cPanel에 배포

1. 모든 파일을 `/home/niphyang/visitor.6developer.com/`에 업로드
2. `passenger_wsgi.py`가 루트 디렉토리에 있는지 확인
3. `.env`에서 데이터베이스 및 Redis 설정 구성
4. cPanel에서 디렉토리를 가리키는 Python 애플리케이션 설정

### 프로젝트 구조

```
visitor-counter/
├── app.py                                # 메인 애플리케이션 파일
├── models.py                             # 데이터베이스 모델
├── passenger_wsgi.py                     # cPanel 진입점
├── requirements.txt                      # 의존성 목록
├── .env                                  # 환경 변수
├── README.md                             # 영문 README
├── README.ko.md                          # 한국어 README
├── static/
│   └── css/
│       └── style.css                     # 스타일시트
├── templates/
│   ├── layout.html                       # 기본 레이아웃
│   ├── index.html                        # 홈페이지
│   ├── api-docs.html                     # API 문서
│   ├── dashboard.html                    # 대시보드
│   ├── login.html                        # 로그인 페이지
│   ├── not-found.html                    # 404 페이지
│   └── error.html                        # 오류 페이지
└── translations/
    ├── en/LC_MESSAGES/messages.po        # 영어 번역
    ├── ko/LC_MESSAGES/messages.po        # 한국어 번역
    └── ja/LC_MESSAGES/messages.po        # 일본어 번역
```

## ⚙️ 구성

### 데이터베이스 스키마

애플리케이션은 두 개의 주요 테이블을 사용합니다:

1. **site**: 추적 중인 각 도메인에 대한 정보 저장
   - id: 기본 키
   - domain: 도메인 이름 (고유)
   - total_count: 총 방문 수
   - today_count: 오늘 방문 수
   - last_visit_date: 마지막 방문 날짜
   - created_at: 사이트가 처음 추적된 시간

2. **visit_log**: 개별 방문 기록 저장
   - id: 기본 키
   - site_id: site 테이블에 대한 외래 키
   - timestamp: 방문 발생 시간

### Redis 구성

Redis는 20분 TTL로 중복 방지에 사용됩니다. 키 형식은 다음과 같습니다:
```
visit:{domain}:{client_ip}:{user_agent}
```

## 🌍 다국어 지원

애플리케이션은 세 가지 언어를 지원합니다:

- 영어 (기본값)
- 한국어
- 일본어

언어 파일은 `translations` 디렉토리에 저장되어 있으며 번역을 추가하거나 수정할 수 있습니다.

## 🤝 기여하기

기여는 언제나 환영합니다! Pull Request를 자유롭게 제출해 주세요.

1. 저장소 포크
2. 기능 브랜치 생성 (`git checkout -b feature/amazing-feature`)
3. 변경 사항 커밋 (`git commit -m 'Add some amazing feature'`)
4. 브랜치에 푸시 (`git push origin feature/amazing-feature`)
5. Pull Request 열기

## 📄 라이선스

이 프로젝트는 MIT 라이선스에 따라 라이선스가 부여됩니다 - 자세한 내용은 LICENSE 파일을 참조하세요.

## 📞 연락처

질문이나 지원이 필요하시면 GitHub에서 이슈를 열어주세요.

---

❤️로 만들어진 [당신의 이름]