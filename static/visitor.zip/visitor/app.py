from flask import Flask, request, jsonify, render_template, redirect, url_for, g, session
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_babel import Babel
import redis
import json
import os
import datetime
import urllib.parse
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'dev_secret_key')

# Database configuration
app.config['SQLALCHEMY_DATABASE_URI'] = f"postgresql://{os.getenv('DB_USER', 'niphyang_dev')}:{os.getenv('DB_PASSWORD', '5Bh3G%[Ji*$9')}@{os.getenv('DB_HOST', 'localhost')}/{os.getenv('DB_NAME', 'niphyang_visitcounter')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Redis configuration
redis_client = redis.Redis(
    host=os.getenv('REDIS_HOST', 'localhost'),
    port=int(os.getenv('REDIS_PORT', 59971)),
    password=os.getenv('REDIS_PASSWORD', ''),
    decode_responses=True
)

# Initialize SQLAlchemy
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Initialize Babel for internationalization
babel = Babel(app)

# Import models after initializing db
from models import Site, VisitLog

@babel.localeselector
def get_locale():
    # Get locale from session, query parameter, or default to English
    return session.get('locale', request.args.get('locale', 'en'))

# Routes
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api-docs')
def api_docs():
    return render_template('api-docs.html')

@app.route('/dashboard')
def dashboard():
    domain = request.args.get('domain')
    if not domain:
        return redirect(url_for('login'))
    
    # Get site data
    site = Site.query.filter_by(domain=domain).first()
    if not site:
        return redirect(url_for('not_found'))
    
    return render_template('dashboard.html', site=site)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        domain = request.form.get('domain', '').strip()
        if domain:
            # Remove http:// or https:// if present
            domain = domain.replace('http://', '').replace('https://', '')
            return redirect(url_for('dashboard', domain=domain))
    
    return render_template('login.html')

@app.route('/not-found')
def not_found():
    return render_template('not-found.html'), 404

@app.route('/set-locale/<locale>')
def set_locale(locale):
    session['locale'] = locale
    return redirect(request.referrer or url_for('home'))

# API Routes
@app.route('/visit', methods=['POST'])
def record_visit():
    data = request.get_json() or {}
    domain = data.get('domain', '')
    timezone = data.get('timezone', 'UTC')
    
    # URL decode domain and timezone
    domain = urllib.parse.unquote(domain)
    timezone = urllib.parse.unquote(timezone)
    
    # Remove http:// or https:// if present
    domain = domain.replace('http://', '').replace('https://', '')
    
    if not domain:
        return jsonify({'error': 'Domain is required'}), 400
    
    # Get or create site
    site = Site.query.filter_by(domain=domain).first()
    if not site:
        site = Site(domain=domain)
        db.session.add(site)
        db.session.commit()
    
    # Check for duplicate visit using Redis
    client_ip = request.remote_addr
    user_agent = request.headers.get('User-Agent', '')
    visit_key = f"visit:{domain}:{client_ip}:{user_agent}"
    
    if not redis_client.exists(visit_key):
        # Set Redis key with 20-minute expiration
        redis_client.setex(visit_key, 1200, 1)  # 1200 seconds = 20 minutes
        
        # Record visit in database
        now = datetime.datetime.now()
        visit_log = VisitLog(site_id=site.id, timestamp=now)
        db.session.add(visit_log)
        db.session.commit()
        
        # Update site counters
        site.total_count += 1
        
        # Get today's date in the specified timezone
        try:
            import pytz
            tz = pytz.timezone(timezone)
            today = datetime.datetime.now(tz).date()
            
            # Check if the last visit was today
            if site.last_visit_date and site.last_visit_date == today:
                site.today_count += 1
            else:
                site.today_count = 1
                site.last_visit_date = today
        except:
            # Fallback to UTC if timezone is invalid
            today = datetime.datetime.utcnow().date()
            if site.last_visit_date and site.last_visit_date == today:
                site.today_count += 1
            else:
                site.today_count = 1
                site.last_visit_date = today
        
        db.session.commit()
    
    # Generate dashboard link
    dashboard_link = url_for('dashboard', domain=domain, _external=True)
    
    return jsonify({
        'todayCount': site.today_count,
        'totalCount': site.total_count,
        'dashboardLink': dashboard_link
    })

@app.route('/visit', methods=['GET'])
def get_visit():
    domain = request.args.get('domain', '')
    
    # URL decode domain
    domain = urllib.parse.unquote(domain)
    
    # Remove http:// or https:// if present
    domain = domain.replace('http://', '').replace('https://', '')
    
    if not domain:
        return jsonify({'error': 'Domain is required'}), 400
    
    # Get site
    site = Site.query.filter_by(domain=domain).first()
    if not site:
        return jsonify({
            'todayCount': 0,
            'totalCount': 0,
            'dashboardLink': url_for('dashboard', domain=domain, _external=True)
        })
    
    # Generate dashboard link
    dashboard_link = url_for('dashboard', domain=domain, _external=True)
    
    return jsonify({
        'todayCount': site.today_count,
        'totalCount': site.total_count,
        'dashboardLink': dashboard_link
    })

# Error handlers
@app.errorhandler(404)
def page_not_found(e):
    return render_template('not-found.html'), 404

@app.errorhandler(500)
def server_error(e):
    return render_template('error.html'), 500

if __name__ == '__main__':
    app.run(debug=True)