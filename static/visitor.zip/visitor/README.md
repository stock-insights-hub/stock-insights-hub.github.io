# Visitor Counter

A lightweight, easy-to-use visitor counter for websites with a beautiful dashboard and API.

![Visitor Counter Dashboard](https://via.placeholder.com/800x400?text=Visitor+Counter+Dashboard)

## 📋 Table of Contents

- [Features](#features)
- [Quick Start](#quick-start)
- [API Documentation](#api-documentation)
- [Installation](#installation)
- [Deployment](#deployment)
- [Configuration](#configuration)
- [Internationalization](#internationalization)
- [Contributing](#contributing)
- [License](#license)

## ✨ Features

- **Real-time Tracking**: Track visitors in real-time with accurate counting and duplicate prevention
- **Responsive Dashboard**: View your visitor statistics on any device with our responsive dashboard
- **Easy Integration**: Simple API makes it easy to integrate with any website or application
- **Multiple Websites**: Track visitors across multiple domains with a single account
- **Multilingual Support**: Available in English, Korean, and Japanese
- **Dark/Light Theme**: Switch between dark and light themes for comfortable viewing
- **Duplicate Prevention**: Uses Redis with a 20-minute TTL to prevent counting the same visitor multiple times
- **Timezone Support**: Calculates "today" based on the visitor's timezone

## 🚀 Quick Start

### 1. Add this script to your website

```html
<script>
  (function() {
    const domain = encodeURIComponent(window.location.hostname);
    const timezone = encodeURIComponent(Intl.DateTimeFormat().resolvedOptions().timeZone);
    
    fetch('https://visitor.6developer.com/visit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ domain, timezone })
    })
    .then(response => response.json())
    .then(data => {
      console.log('Visitor count:', data);
      // You can display the count on your page
      if (document.getElementById('visitor-count')) {
        document.getElementById('visitor-count').textContent = data.totalCount;
      }
    })
    .catch(error => console.error('Error:', error));
  })();
</script>
```

### 2. Display the counter on your page (optional)

```html
<div>
  Visitors: <span id="visitor-count">0</span>
</div>
```

### 3. View your statistics

Access your visitor statistics dashboard by entering your domain at [https://visitor.6developer.com/login](https://visitor.6developer.com/login)

## 📊 API Documentation

### POST /visit

Increment the visitor count for a domain.

#### Request

```
POST https://visitor.6developer.com/visit
Content-Type: application/json

{
  "domain": "example.com",
  "timezone": "Asia/Seoul"
}
```

#### Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| domain | string | Yes | The domain name (URL encoded, without http:// or https://) |
| timezone | string | No | The timezone for calculating "today" (URL encoded, defaults to UTC) |

#### Response

```json
{
  "todayCount": 42,
  "totalCount": 1337,
  "dashboardLink": "https://visitor.6developer.com/dashboard?domain=example.com"
}
```

#### Notes

- Duplicate visits from the same IP and user agent within 20 minutes are not counted
- The "todayCount" is calculated based on the provided timezone

### GET /visit

Get the current visitor count for a domain without incrementing it.

#### Request

```
GET https://visitor.6developer.com/visit?domain=example.com
```

#### Parameters

| Name | Type | Required | Description |
|------|------|----------|-------------|
| domain | string | Yes | The domain name (URL encoded, without http:// or https://) |

#### Response

```json
{
  "todayCount": 42,
  "totalCount": 1337,
  "dashboardLink": "https://visitor.6developer.com/dashboard?domain=example.com"
}
```

## 💻 Installation

### Requirements

- Python 3.9+
- PostgreSQL
- Redis

### Setup

1. Clone the repository:

```bash
git clone https://github.com/yourusername/visitor-counter.git
cd visitor-counter
```

2. Create a virtual environment and install dependencies:

```bash
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
```

3. Set up the database:

```bash
flask db init
flask db migrate
flask db upgrade
```

4. Configure environment variables in `.env` file:

```
DB_USER=niphyang_dev
DB_PASSWORD=5Bh3G%[Ji*$9
DB_HOST=localhost
DB_NAME=niphyang_visitcounter
REDIS_HOST=localhost
REDIS_PORT=59971
REDIS_PASSWORD=
SECRET_KEY=your_secure_secret_key_here
FLASK_ENV=production
```

5. Run the application:

```bash
flask run
```

## 🌐 Deployment

### Deployment on cPanel

1. Upload all files to `/home/niphyang/visitor.6developer.com/`
2. Make sure `passenger_wsgi.py` is in the root directory
3. Configure the database and Redis settings in `.env`
4. Set up a Python application in cPanel pointing to the directory

### Project Structure

```
visitor-counter/
├── app.py                                # Main application file
├── models.py                             # Database models
├── passenger_wsgi.py                     # cPanel entry point
├── requirements.txt                      # Dependencies
├── .env                                  # Environment variables
├── README.md                             # English README
├── README.ko.md                          # Korean README
├── static/
│   └── css/
│       └── style.css                     # Stylesheet
├── templates/
│   ├── layout.html                       # Base layout
│   ├── index.html                        # Homepage
│   ├── api-docs.html                     # API documentation
│   ├── dashboard.html                    # Dashboard
│   ├── login.html                        # Login page
│   ├── not-found.html                    # 404 page
│   └── error.html                        # Error page
└── translations/
    ├── en/LC_MESSAGES/messages.po        # English translations
    ├── ko/LC_MESSAGES/messages.po        # Korean translations
    └── ja/LC_MESSAGES/messages.po        # Japanese translations
```

## ⚙️ Configuration

### Database Schema

The application uses two main tables:

1. **site**: Stores information about each domain being tracked
   - id: Primary key
   - domain: Domain name (unique)
   - total_count: Total number of visits
   - today_count: Number of visits today
   - last_visit_date: Date of the last visit
   - created_at: When the site was first tracked

2. **visit_log**: Stores individual visit records
   - id: Primary key
   - site_id: Foreign key to site table
   - timestamp: When the visit occurred

### Redis Configuration

Redis is used for duplicate prevention with a 20-minute TTL. The key format is:
```
visit:{domain}:{client_ip}:{user_agent}
```

## 🌍 Internationalization

The application supports three languages:

- English (default)
- Korean (한국어)
- Japanese (日本語)

Language files are stored in the `translations` directory and can be edited to add or modify translations.

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 📞 Contact

For questions or support, please open an issue on GitHub.

---

Made with ❤️ by [Your Name]