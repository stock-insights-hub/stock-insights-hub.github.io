CREATE TABLE IF NOT EXISTS site (
  id SERIAL PRIMARY KEY,
  domain TEXT UNIQUE NOT NULL,
  registered_at TIMESTAMP DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS visit_log (
  id SERIAL PRIMARY KEY,
  url TEXT NOT NULL,
  fingerprint TEXT NOT NULL,
  referrer TEXT,
  keyword TEXT,
  timezone TEXT,
  visited_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_visit_log_url ON visit_log (url);
CREATE INDEX IF NOT EXISTS idx_visit_log_visited_at ON visit_log (visited_at);
