import React from "react";
import VisitCounterComponent from "./VisitCounterComponent";

const App = () => {
  return (
    <div>
      <h1>Sample App</h1>
      <VisitCounterComponent />
    </div>
  );
};

export default App;