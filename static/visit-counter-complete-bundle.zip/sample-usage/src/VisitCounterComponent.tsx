import React from "react";
import { useVisitCounter } from "free-visit-counter";

const VisitCounterComponent = () => {
  const { todayCount, totalCount, dashboardLink } = useVisitCounter();

  return (
    <div>
      <h2>Visit Counter</h2>
      <p>Today's Visits: {todayCount}</p>
      <p>Total Visits: {totalCount}</p>
      <a href={dashboardLink} target="_blank" rel="noopener noreferrer">View Statistics</a>
    </div>
  );
};

export default VisitCounterComponent;