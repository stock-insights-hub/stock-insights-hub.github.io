import psycopg2
import os
from datetime import datetime
import pytz

def get_db_connection():
    return psycopg2.connect(
        host=os.getenv("POSTGRES_HOST"),
        port=os.getenv("POSTGRES_PORT"),
        dbname=os.getenv("POSTGRES_DB"),
        user=os.getenv("POSTGRES_USER"),
        password=os.getenv("POSTGRES_PASSWORD")
    )

def get_site_id(conn, domain):
    with conn.cursor() as cur:
        cur.execute("SELECT id FROM site WHERE domain = %s", (domain,))
        row = cur.fetchone()
        return row[0] if row else None

def insert_visit(conn, site_id, timezone):
    with conn.cursor() as cur:
        cur.execute("INSERT INTO visit_log (site_id, timezone) VALUES (%s, %s)", (site_id, timezone))
    conn.commit()

def get_visit_stats(conn, site_id, timezone_str):
    tz = pytz.timezone(timezone_str)
    today_start = datetime.now(tz).replace(hour=0, minute=0, second=0, microsecond=0).astimezone(pytz.utc)
    with conn.cursor() as cur:
        cur.execute("SELECT COUNT(*) FROM visit_log WHERE site_id = %s", (site_id,))
        total = cur.fetchone()[0]
        cur.execute("SELECT COUNT(*) FROM visit_log WHERE site_id = %s AND created_at >= %s", (site_id, today_start))
        today = cur.fetchone()[0]
    return today, total