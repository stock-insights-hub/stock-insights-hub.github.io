from flask import Flask, request, jsonify, render_template
from dotenv import load_dotenv
import os
from redis_cache import is_duplicate_visit
from db.models import get_db_connection, get_site_id, insert_visit, get_visit_stats

load_dotenv()

app = Flask(__name__, template_folder="templates", static_folder="static")

@app.route("/visit", methods=["GET", "POST"])
def visit():
    domain = request.args.get("domain") if request.method == "GET" else request.json.get("domain")
    timezone = request.args.get("timezone") if request.method == "GET" else request.json.get("timezone")
    ip_address = request.remote_addr

    if not domain or not timezone:
        return jsonify({"error": "Missing required parameters"}), 400

    conn = get_db_connection()
    site_id = get_site_id(conn, domain)
    if not site_id:
        return jsonify({"error": "Domain not registered"}), 404

    if request.method == "POST" and not is_duplicate_visit(domain, ip_address):
        insert_visit(conn, site_id, timezone)

    today_count, total_count = get_visit_stats(conn, site_id, timezone)
    dashboard_link = f"https://visitor.6developer.com/dashboard?domain={domain}&timezone={timezone}"

    return jsonify({
        "todayCount": today_count,
        "totalCount": total_count,
        "dashboardLink": dashboard_link
    })

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/install-guide")
def install_guide():
    return render_template("install_guide.html")

@app.route("/api-docs")
def api_docs():
    return render_template("api_docs.html")

@app.route("/dashboard")
def dashboard():
    return render_template("dashboard.html")

@app.errorhandler(404)
def not_found(e):
    return render_template("404.html"), 404