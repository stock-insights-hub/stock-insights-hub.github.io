# Visit Counter Backend (v1.0.5)

A lightweight Flask backend to track visit statistics for your website — supports timezone-based visit count, Redis-based duplication prevention, PostgreSQL storage, and multilingual SEO-ready UI.

## Features

- RESTful API: `GET /visit`, `POST /visit`
- Timezone-aware "today" visit count
- Redis-based duplicate filtering (20-minute rule per IP)
- PostgreSQL integration for persistence
- Prebuilt UI: `/`, `/install-guide`, `/api-docs`, `/dashboard`, `/login`, `/not-found`
- Multilingual support: English, Korean, Japanese
- Dark/Light mode toggle
- Responsive layout and SEO meta tags

## Installation

```bash
pip install -r requirements.txt
```

Set environment variables in `.env`:

```
FLASK_ENV=production
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=visit_counter
POSTGRES_USER=niphyang_dev
POSTGRES_PASSWORD=your_password
REDIS_HOST=localhost
REDIS_PORT=59971
```

## Usage

```bash
python app.py
```

Or deploy via `passenger_wsgi.py` on cPanel.

## API

### `GET /visit?domain=example.com&timezone=Asia/Seoul`
Returns visit stats without incrementing.

### `POST /visit`
```json
{
  "domain": "example.com",
  "timezone": "Asia/Seoul"
}
```

Returns stats and increments count if not duplicated.

## Project Structure

- `app.py`: Flask entrypoint
- `db/models.py`: PostgreSQL handling
- `redis_cache.py`: Redis duplicate filter
- `templates/`: HTML templates
- `static/`: CSS/JS/lang assets
- `.env`: environment config
- `passenger_wsgi.py`: for cPanel deployment

## License

MIT License

## Author

**RUN:DEVEL:RUN** — https://github.com/rundevelrun

_Read this in other languages: [한국어 README](README.ko.md)_