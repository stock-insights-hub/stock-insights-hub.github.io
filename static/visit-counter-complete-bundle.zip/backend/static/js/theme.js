function toggleTheme() {
  const body = document.body;
  body.classList.toggle("dark");
  localStorage.setItem("theme", body.classList.contains("dark") ? "dark" : "light");
}
window.onload = () => {
  const saved = localStorage.getItem("theme");
  if (saved) document.body.classList.add(saved);
}