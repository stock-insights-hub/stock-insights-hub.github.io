function switchLanguage(lang) {
  fetch(`/static/lang/${lang}.json`)
    .then(res => res.json())
    .then(dict => {
      for (const key in dict) {
        const el = document.querySelector(`[data-i18n="${key}"]`);
        if (el) el.textContent = dict[key];
      }
    });
}