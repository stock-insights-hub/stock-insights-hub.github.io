# 방문자 수 카운터 백엔드 (v1.0.5)

이 프로젝트는 웹사이트의 방문자를 효율적으로 추적할 수 있도록 설계된 Flask 기반 백엔드입니다.  
시간대 기반의 방문자 수 계산, Redis 중복 방지, PostgreSQL 저장소, 다국어 UI 및 SEO 대응 기능을 갖추고 있습니다.

## 주요 기능

- REST API 제공: `GET /visit`, `POST /visit`
- 타임존 기반 오늘 방문자 수 계산
- Redis를 통한 20분 내 중복방문 차단
- PostgreSQL을 통한 방문 기록 저장
- UI 페이지 제공: `/`, `/install-guide`, `/api-docs`, `/dashboard`, `/login`, `/not-found`
- 다국어 지원: 영어, 한국어, 일본어
- 다크/라이트 테마 전환 지원
- 반응형 레이아웃, SEO 메타태그 최적화

## 설치

```bash
pip install -r requirements.txt
```

`.env` 파일에 환경변수 설정:

```
FLASK_ENV=production
POSTGRES_HOST=localhost
POSTGRES_PORT=5432
POSTGRES_DB=visit_counter
POSTGRES_USER=niphyang_dev
POSTGRES_PASSWORD=비밀번호
REDIS_HOST=localhost
REDIS_PORT=59971
```

## 실행 방법

```bash
python app.py
```

또는 cPanel의 `passenger_wsgi.py`를 통해 배포 가능.

## API 명세

### `GET /visit?domain=example.com&timezone=Asia/Seoul`
- 방문자 수를 조회만 합니다.

### `POST /visit`
```json
{
  "domain": "example.com",
  "timezone": "Asia/Seoul"
}
```
- 중복이 아닌 경우 1회 방문자로 기록됩니다.

## 프로젝트 구조

- `app.py`: Flask 진입점
- `db/models.py`: PostgreSQL 연동 처리
- `redis_cache.py`: Redis 중복 필터
- `templates/`: HTML 템플릿
- `static/`: CSS, JS, 언어 파일
- `.env`: 환경변수
- `passenger_wsgi.py`: cPanel 배포용

## 라이선스

MIT License

## 제작자

**RUN:DEVEL:RUN** — https://github.com/rundevelrun

_다른 언어로 보기: [English README](README.md)_