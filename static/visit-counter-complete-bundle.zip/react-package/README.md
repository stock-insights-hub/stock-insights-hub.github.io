# free-visit-counter

React hook to track visit counts with optional backend API integration.

## Installation

```bash
npm install free-visit-counter
```

## Usage

```tsx
import { useVisitCounter } from "free-visit-counter";

const Component = () => {
  const { todayCount, totalCount, dashboardLink } = useVisitCounter();
  return (
    <>
      <p>Today: {todayCount}</p>
      <p>Total: {totalCount}</p>
      <a href={dashboardLink} target="_blank">View Dashboard</a>
    </>
  );
};
```

## Options

| Name      | Type     | Default                         | Description                  |
|-----------|----------|----------------------------------|------------------------------|
| domain    | `string` | `window.location.origin`         | Domain to count visits for  |
| endpoint  | `string` | `https://visitor.6developer.com/visit` | Custom API endpoint |
| timezone  | `string` | User's system timezone           | Visit timestamp base        |
| method    | `"GET"` \| `"POST"` | `"GET"`            | HTTP method for the request |

## License

MIT License