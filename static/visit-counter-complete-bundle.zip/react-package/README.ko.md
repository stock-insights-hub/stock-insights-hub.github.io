# free-visit-counter

React 프로젝트에서 방문자 수를 추적할 수 있는 훅입니다.  
백엔드 API 연동이 가능하며, 도메인 기반 통계 대시보드를 제공합니다.

## 설치

```bash
npm install free-visit-counter
```

## 사용 예시

```tsx
import { useVisitCounter } from "free-visit-counter";

const Component = () => {
  const { todayCount, totalCount, dashboardLink } = useVisitCounter();
  return (
    <>
      <p>오늘 방문자: {todayCount}</p>
      <p>전체 방문자: {totalCount}</p>
      <a href={dashboardLink} target="_blank">통계 보기</a>
    </>
  );
};
```

## 옵션

| 옵션명     | 타입      | 기본값                               | 설명                  |
|------------|-----------|----------------------------------------|-----------------------|
| domain     | `string`  | `window.location.origin`              | 카운트할 도메인       |
| endpoint   | `string`  | `https://visitor.6developer.com/visit` | API 서버 주소         |
| timezone   | `string`  | 사용자 시스템의 시간대               | 방문자 기준 시간대     |
| method     | `"GET"` 또는 `"POST"` | `"GET"` | 요청 방식             |

## 라이선스

MIT License