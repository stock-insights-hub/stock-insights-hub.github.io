import { useEffect, useState } from "react";

interface VisitData {
  todayCount: number;
  totalCount: number;
  dashboardLink: string;
}

interface VisitOptions {
  domain?: string;
  endpoint?: string;
  timezone?: string;
  method?: "GET" | "POST";
}

export const useVisitCounter = (options: VisitOptions = {}): VisitData => {
  const [todayCount, setTodayCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);
  const [dashboardLink, setDashboardLink] = useState("#");

  useEffect(() => {
    const domain = options.domain || window.location.origin;
    const endpoint = options.endpoint || "https://visitor.6developer.com/visit";
    const timezone = options.timezone || Intl.DateTimeFormat().resolvedOptions().timeZone;
    const method = options.method || "GET";

    const body = JSON.stringify({ domain, timezone });
    const url = `${endpoint}?domain=${encodeURIComponent(domain)}&timezone=${encodeURIComponent(timezone)}`;

    fetch(url, {
      method,
      headers: { "Content-Type": "application/json" },
      ...(method === "POST" ? { body } : {})
    })
    .then(res => res.json())
    .then(data => {
      setTodayCount(data.todayCount || 0);
      setTotalCount(data.totalCount || 0);
      setDashboardLink(data.dashboardLink || "#");
    })
    .catch(() => {
      setDashboardLink("https://visitor.6developer.com/dashboard?domain=" + encodeURIComponent(domain));
    });
  }, []);

  return { todayCount, totalCount, dashboardLink };
};