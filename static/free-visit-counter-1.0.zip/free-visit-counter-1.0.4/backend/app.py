from flask import Flask, render_template, request, jsonify
import os
from dotenv import load_dotenv

load_dotenv()
app = Flask(__name__, template_folder="templates", static_folder="static")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/install-guide")
def install_guide():
    return render_template("install_guide.html")

@app.route("/api-docs")
def api_docs():
    return render_template("api_docs.html")

@app.route("/stats/login")
def stats_login():
    return render_template("login.html")

@app.route("/stats/sample-dashboard")
def sample_dashboard():
    return render_template("sample_dashboard.html")

@app.route("/api/visit", methods=["GET", "POST"])
def api_visit():
    if request.method == "POST":
        return jsonify({"message": "Visit counted."})
    return jsonify({"total_count": 12345, "dashboard": "/stats/sample-dashboard"})

application = app
